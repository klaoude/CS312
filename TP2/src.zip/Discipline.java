
public enum Discipline {
	Automatique,
	Informatique,
	Electronique,
	R�seau;
}
