import java.util.*;


 public class Activit� {
	private String nom;
	private ArrayList<Groupe> groupes;
	private ArrayList<Salle> sallesAppropri�es;
	
	public Activit�(String nom){
		this.nom = new String(nom);
		groupes = new ArrayList<Groupe>();
		sallesAppropri�es = new ArrayList<Salle>();
	}
	
	public void addGroupe(Groupe groupe){
		groupes.add(groupe);
	}
	
	protected void addSalle(Salle s){ 
		sallesAppropri�es.add(s); 
	}
	
	public ArrayList<Salle>  getSalles(){
		return sallesAppropri�es;
	}
	
	public ArrayList<Groupe> getGroupes(){
		return groupes;
	}
	
	public String toString(){
		return "Activit� " + nom + " (" + groupes +")";
	}
}
