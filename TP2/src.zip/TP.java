
public class TP extends Activit�{
	public TP(String nom){
		super(nom);
	}
	
	public void addSalle(SalleTP s){
		super.addSalle(s);
	}
}
