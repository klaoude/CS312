
public class TD extends Activit�{
	public TD(String nom){
		super(nom);
	}
	
	public void addSalle(SalleCTD s){
		super.addSalle(s);
	}
}
